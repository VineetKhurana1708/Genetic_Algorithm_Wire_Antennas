function return=example_fun(arg1, arg2, arg3)
	% <one line description>
	%
	% <more detailed description>
	% <more detailed description>
	% <more detailed description>
	%
    % Parameters :
    % arg1: 		This arg1 takes a value
    % arg2:			<some description about arg2>
    % arg3:			(optional) This argument is optional. Default value is 0
    %
    % @retval return Description about the written value
    % 
    % @note 
    % 1. <some notes>
    % 2. <some other notes>
    % 
    % Example :
    % @code
    % val1=example_fun(1,2,3)
    % val2=example_fun(1,2)
    % # @endcode
    %
    % @author Rounak Singh, rounaksingh17@gmail.com
    %
    % @date 28 July 2015

    %-------------This line is not necessary. you may use it as a separator between ur code and documentation block------------------------------------

    Code here.

end
